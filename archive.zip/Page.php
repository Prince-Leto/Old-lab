<?php
	require('Template.php');
	$Page = new Page();
	if(isset($_GET['id']))
	{
		$Get = $Page->VerifierID($_GET['id']);
		if($Get !== false and !empty($Get))
		{
			$Page->Tete($Get['Titre'], $Get['Titre'], "Page.css", "Load.js", $Get);
			$Page->BeginMenu();
			$Page->Article($_GET['id']);
			$Page->Header($Get['Titre']);
			$Page->Nav();
			$Page->EndMenu();
			$Page->Canvas();
			$Page->EndPage();
		}
		else
		{
			$Page->Erreur(404);
		}
	}
	else
	{
		$Page->Erreur(404);
	}
?>