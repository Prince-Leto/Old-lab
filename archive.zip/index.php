<?php
	require('Template.php');
	$Page = new Page();
	$Page->Tete("Le Laboratoire de Leto", "Démonstrations d'utilisation de la balise canvas en Javascript avec des automates-cellulaires et des fractales.", "CustomBar.css", "Charger.js");
	$Page->Header("Le Laboratoire de Leto");
	$Page->BeginMenu();
	$Page->Nav();
	$Page->EndMenu();
	$Page->Articles();
	$Page->EndPage();
?>