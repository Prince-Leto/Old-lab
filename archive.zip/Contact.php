<?php
	if(isset($_POST['Nom']) && isset($_POST['Mail']) && isset($_POST['Text']))
	{
		if(!empty($_POST['Nom']) && !empty($_POST['Mail']) && !empty($_POST['Text']))
		{
			$message_html = "<html><head></head><body><p>Envoyé par : ".$_POST['Nom']." - ".$_POST['Mail']."</p><pre style=\"font-size: 12px;\">".$_POST['Text']."</pre></body></html>";
			$boundary = "-----=".md5(rand());
			$sujet = "Commentaire de ".$_POST['Nom'];
			$header = "From: \"Lelaboratoiredeleto\"<admin@lelaboratoiredeleto.tk>\r\n";
			$header .= "Reply-to: \"Lelaboratoiredeleto\"<admin@lelaboratoiredeleto.tk>\r\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= "Content-Type: multipart/alternative;\r\n boundary=\"$boundary\"\r\n";
			$message = "\r\n"."--".$boundary."\r\n";
			$message .= "Content-Type: text/html; charset=\"UTF-8\"\r\n";
			$message .= "Content-Transfer-Encoding: 8bit\r\n";
			$message .= "\r\n".$message_html."\r\n";
			$message .= "\r\n"."--".$boundary."--\r\n";
			$Output = mail("gchauvet.home@gmail.com", $sujet, $message, $header);
		}
		else
		{
			$Output = false;
		}
	}
	require('Template.php');
	$Page = new Page();
	$Page->Tete("Contact - Le Laboratoire de Leto", "Page de conPro", "CustomBar.css", "");
	$Page->Header("Le Laboratoire de Leto");
	$Page->BeginMenu();
	$Page->Nav();
	$Page->EndMenu();
	?>
	<article>
		<?php
		if(isset($Output))
		{
			if($Output === true)
			{
				echo "<p style=\"color: green; padding-top: 20px\">Votre message a bien été envoyé.</p>";
			}
			elseif($Output === false)
			{
				echo "<p style=\"color: red; padding-top: 20px\">Erreur lors de l'envoi du message.</p>";
			}
		}
		?>
		<p style="padding: 20px 0;">Envoyez-moi un message pour parler de tout et n'importe quoi à propos de mon site. Laissez-moi votre adresse e-mail pour que je puisse vous répondre.</p>
		<form action="Contact" method="post">
			<label for="Name" style="display: inline-block; width: 100px; text-align: right; margin-right: 5px;">Nom</label><input id="Name" type="text" name="Nom" autocomplete="off"/><br />
			<label for="Mail" style="display: inline-block; width: 100px; text-align: right; margin-right: 5px;">E-mail</label><input id="Mail" type="email" name="Mail" autocomplete="off"/><br />
			<label for="Content" style="display: inline-block; width: 100px; text-align: right; margin-right: 5px;">Message</label><textarea id="Content" rows="6" cols="50" name="Text" style="vertical-align: top; min-width: 85%; max-width: 85%;"></textarea><br />
			<input style="margin-left: 106px; margin-top: 10px;" type="submit" value="Envoyer"/>
		</form>
	</article>
	<?php
	$Page->EndPage();
?>