<?php
	require('Template.php');
	$Page = new Page();
	if(isset($_GET['id']))
	{
		$Get = $Page->MakeID($_GET['id']);
		if($Get !== false and !empty($Get))
		{
			$Page->Tete("Making Of ".$Get['Titre'], "Making Of ".$Get['Titre'], "CustomBar.css", "");
			$Page->Header("Making Of ".$Get['Titre']);
			$Page->BeginMenu();
			$Page->Nav();
			$Page->EndMenu();
			$Page->ChargerMake($Get['ID']);
			$Page->EndPage();
		}
		else
		{
			$Page->Erreur(404);
		}
	}
	else
	{
		$Page->Erreur(404);
	}
?>