<?php
	ini_set('display_errors', 1);

	require('Template.php');
	$Page = new Page();
	$Page->Tete("Erreur - Le Laboratoire de Leto", "Erreur 404", "/CustomBar.css", "");
	$Page->Header("Le Laboratoire de Leto");
	$Page->BeginMenu();
	$Page->Nav();
	$Page->EndMenu();
	?>
	<article>
		<p style="padding: 20px 0;">
		Cette page n'existe pas...
		</p>
	</article>
	<?php
	$Page->EndPage();
?>
