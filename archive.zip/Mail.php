<?php
	if(isset($_POST['Destinataire']) && isset($_POST['Mail']) && isset($_POST['Text']) && isset($_POST['Objet']) && isset($_POST['RMessage']))
	{
		if(!empty($_POST['Destinataire']) && !empty($_POST['Mail']) && !empty($_POST['Text']) && !empty($_POST['Objet']) && !empty($_POST['RMessage']))
		{
			$message_html = "<html><head><style>".$_POST['RStyle']."</style></head><body>".$_POST['RMessage']."</body></html>";
			$boundary = "-----=".md5(rand());
			$header = "From: <".$_POST['Mail'].">\r\n";
			$header .= "Reply-to: <".$_POST['Mail'].">\r\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= "Content-Type: multipart/alternative;\r\n boundary=\"$boundary\"\r\n";
			$message = "\r\n"."--".$boundary."\r\n";
			$message .= "Content-Type: text/html; charset=\"UTF-8\"\r\n";
			$message .= "Content-Transfer-Encoding: 8bit\r\n";
			$message .= "\r\n".$message_html."\r\n";
			$message .= "\r\n"."--".$boundary."--\r\n";
			echo $message_html;
			$Output = mail($_POST['Destinataire'], $_POST['Objet'], $message, $header);
		}
		else
		{
			$Output = false;
		}
	}
	require('Template.php');
	$Page = new Page();
	$Page->Tete("Contact - Le Laboratoire de Leto", "CustomBar.css", "Actions.js");
	$Page->Header("Le Laboratoire de Leto");
	$Page->BeginMenu();
	$Page->Nav();
	$Page->EndMenu();
	?>
	<article>
		<?php
		if($Output === true)
		{
			echo "<p style=\"color: green; padding-top: 20px\">Votre message a bien été envoyé.</p>";
		}
		elseif($Output === false)
		{
			echo "<p style=\"color: red; padding-top: 20px\">Erreur lors de l'envoi du message.</p>";
		}
		?>
		<script type="text/javascript" src="http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML"></script>
		<p style="padding: 20px 0;">Envoyez un e-mail contenant du \(\LaTeX\).</p>
		<form action="Mail" method="post">
			<label for="Name" style="display: inline-block; width: 110px; text-align: right; margin-right: 5px;">Destinataire</label><input id="Name" type="email" name="Destinataire" autocomplete="off"/><br />
			<label for="Mail" style="display: inline-block; width: 110px; text-align: right; margin-right: 5px;">Expéditeur</label><input id="Mail" type="email" name="Mail" autocomplete="off"/><br />
			<label for="Mail" style="display: inline-block; width: 110px; text-align: right; margin-right: 5px;">Objet</label><input id="Mail" type="text" name="Objet" autocomplete="off"/><br />
			<label for="Content" style="display: inline-block; width: 110px; text-align: right; margin-right: 5px;">Message</label><textarea id="Content" rows="6" cols="50" name="Text" style="vertical-align: top; min-width: 85%; max-width: 85%;"></textarea><br />
			<input id="Prev" type="button" value="Aperçu" style="margin-left: 116px; margin-top: 10px;"/>
			<input type="submit" value="Envoyer" disabled="true"/>
			<p id="RContent"></p>
			<input id="RMessage" name="RMessage" type="hidden"/>
			<input id="RStyle" name="RStyle" type="hidden"/>
		</form>
	</article>
	<?php
	$Page->EndPage();
?>