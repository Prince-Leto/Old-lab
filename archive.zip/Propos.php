<?php
	require('Template.php');
	$Page = new Page();
	$Page->Tete("À propos - Le Laboratoire de Leto", "À propos du créateur", "CustomBar.css", "");
	$Page->Header("Le Laboratoire de Leto");
	$Page->BeginMenu();
	$Page->Nav();
	$Page->EndMenu();
	?>
	<article>
		<p style="padding: 20px 0;">
		Bienvenue sur Le Laboratoire de Leto.<br />
		Pourquoi Leto ? C'est tout simplement le pseudo' que j'utilise depuis mes débuts sur Internet.<br />
		Entièrement créé par moi-même dans la tradition du web et en respectant les standards, ce site a pour vocation de présenter les quelques dessins que j'ai pu faire avec la nouvelle balise <code>&lt;canvas&gt;</code>.<br />
		Sur ce, bonne navigation.
		</p>
	</article>
	<?php
	$Page->EndPage();
?>
