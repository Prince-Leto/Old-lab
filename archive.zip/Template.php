<?php
class Page
{
	function __construct()
	{
		require("Connexion.php");
		$this->bdd = $bdd;
		header("Content-Type: application/xhtml+xml");
	}

	function Tete($Titre, $Description, $Style, $Script, $Get = false)
	{
		?><!DOCTYPE html>
		<html xmlns="http://www.w3.org/1999/xhtml" lang="fr">
		<head>
			<meta charset="UTF-8"/>
			<title><?php echo $Titre; ?></title>
			<meta name="description" content="<?php echo $Description; ?>"/>
			<link rel="stylesheet" href="/Styles/Style.css" media="screen"/>
			<link rel="stylesheet" href="/Styles/Min.css" media="screen and (max-width: 950px)"/>
			<?php
			if($Style == "CustomBar.css" && strpos(strtolower($_SERVER['HTTP_USER_AGENT']), "webkit") !== false && false)
			{
				?>
				<link rel="stylesheet" href="Styles/CustomBar.css"/>
				<?php
			}
			elseif($Style != "" && $Style != "CustomBar.css")
			{
				?>
				<link rel="stylesheet" href="<?php echo "Styles/".$Style; ?>"/>
				<?php
			}
			?>
			<link rel="icon" type="image/png" href="Images/Favicon.png"/>
			<script type="text/javascript">
 			// Google Analytics :
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

			ga('create', 'UA-36757770-3', 'auto');
			ga('send', 'pageview');
			</script>
			<script src="Scripts/<?php echo $Script; ?>"></script>
			<?php
			if($Get !== false)
			{
				$Var
				?>
				<script src="Ressources/<?php echo $Get['Ressources']; ?>/Code.js"></script>
				<?php
			}
			?>
		</head>
		<body>
		<?php
	}

	function Header($Titre)
	{
		?>
			<header>
				<h1><a href="/" title="Accueil"><?php echo $Titre; ?></a></h1>
			</header>
		<?php
	}

	function Nav()
	{
		?>
			<nav>
				<span id="Articles">Articles
				<ul>
				<?php
					$Query = $this->bdd->query('SELECT ID, Titre FROM Articles ORDER BY Date DESC');
					while($Data = $Query->fetch())
					{
						echo "<li><a href=\"Page-" . $Data['ID'] . "\">" . $Data['Titre'] . "</a></li>";
					}
					$Query->closeCursor();
				?>
				</ul>
				</span>
				<a id="Contact" href="ContactMe">Contact</a>
				<a id="Propos" href="Apropos">À propos</a>
			</nav>
		<?php
	}

	function BeginMenu()
	{
		?>
			<div id="Menu">
		<?php
	}

	function EndMenu()
	{
		?>
			</div>
		<?php
	}

	function Articles()
	{
		$Query = $this->bdd->query('SELECT ID, Titre, Ressources, Contenu, Plus, Date FROM Articles ORDER BY Date DESC');
		setlocale(LC_TIME, 'fr', 'fr_FR', 'fr_FR.UTF-8');
		$Mois = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
		/*utf8_encode(ucfirst(strftime("%B", $Data['Date'])))*/ // Format français non reconnu sur olympe.in
		while($Data = $Query->fetch())
		{
			$Nombre = $this->bdd->query('SELECT COUNT(*) AS Nombre FROM Commentaires WHERE Reference = '.$Data['ID'])->fetch();
			?>
			<article>
				<h2><a href="Page-<?php echo $Data['ID']; ?>"><?php echo $Data['Titre']; ?></a></h2>
				<time datetime="<?php echo strftime("%Y-%m-%d", $Data['Date']); ?>"><?php echo strftime("%d", $Data['Date'])." ".$Mois[date("n", $Data['Date']) - 1]." ".strftime("%Y", $Data['Date']); ?></time>
				<a href="Page-<?php echo $Data['ID']; ?>"><img src="Ressources/<?php echo $Data['Ressources']; ?>/Image.png" width="200" alt="<?php echo $Data['Titre']?>"></img></a>
				<p><?php echo $Data['Contenu']; ?></p>
				<?php
					if(!empty($Data['Plus']))
					{
						?>
						<div class="Plus">
							<p><strong>En savoir plus :</strong></p>
							<p><?php echo $Data['Plus']; ?></p>
						</div>
						<?php
					}
				?>
				<div class="Commentaires">
				<?php
				if($Nombre['Nombre'] != 1 && $Nombre['Nombre'] != 0)
				{
					?>
					<span><?php echo $Nombre['Nombre']; ?> commentaires</span>
					<?php
				}
				else
				{
					?>
					<span><?php echo $Nombre['Nombre']; ?> commentaire</span>
					<?php
				}
				?>
					<div>
						<?php
						$Next = $this->bdd->query('SELECT Texte, Temps FROM Commentaires WHERE Reference = '.$Data['ID'].' ORDER BY Temps');
						while($Do = $Next->fetch())
						{
							?>
							<p><?php echo $Do['Texte']; ?><time datetime="<?php echo strftime("%Y-%m-%d", $Do['Temps']); ?>"><?php echo strftime("%d", $Do['Temps'])." ".$Mois[date("n", $Data['Date']) - 1]." ".strftime("%Y", $Do['Temps']); ?></time></p>
							<?php
						}
						$Next->closeCursor();
						?>
						<p><span contenteditable="true" data-ref="<?php echo $Data['ID']?>">Pour ajouter un commentaire : éditez-moi !</span><span><input type="button" value="Envoyer"/></span></p>
					</div>
				</div>
				<div class="Infos">
					<?php
					if(!empty($Data['Plus']))
					{
						?>
						<span>En savoir plus</span>
						<?php
					}
					else
					{
						?>
						<span title="Pas encore disponible" style="text-decoration: line-through;">En savoir plus</span>
						<?php
					}
					$M = $this->bdd->query('SELECT Texte FROM Make WHERE Reference = '.$Data['ID'])->fetch();
					if(!empty($M))
					{
						?>
						<a href="Make-<?php echo $Data['ID']; ?>">Making Of</a>
						<?php
					}
					else
					{
						?>
						<a href="" title="Pas encore disponible" style="text-decoration: line-through;">Making Of</a>
						<?php
					}
					?>
				</div>
			</article>
			<?php
		}
		$Query->closeCursor();
	}

	function Article($id)
	{
		$Data = $this->bdd->query('SELECT Ressources FROM Articles WHERE ID = '.$id)->fetch();
		?>
		<div id="Navigate">
			<span id="Parametres">Paramètres</span>
			<div>
				<input id="Visible" type="checkbox" checked="checked"/><label for="Visible">Menu toujours visible</label><br />
				<?php include("Ressources/".$Data['Ressources']."/Parametre.html"); ?>
			</div>
			<span id="Documentation">Documentation</span>
			<div>
				<?php include("Ressources/".$Data['Ressources']."/Documentation.html"); ?>
			</div>
		</div>
		<?php
	}

	function Canvas()
	{
		?>
		<canvas></canvas>
		<?php
	}

	function VerifierID($id)
	{
		if($id !== "")
		{
			return $this->bdd->query('SELECT Titre, Ressources FROM Articles WHERE ID = '.$id)->fetch();
		}
		else
		{
			return false;
		}
	}

	function MakeID($id)
	{
		if($id !== "")
		{
			return $this->bdd->query('SELECT Make.ID, Articles.Titre, Make.Texte FROM Articles, Make WHERE Make.Reference = Articles.ID AND Articles.ID = '.$id)->fetch();
		}
		else
		{
			return false;
		}
	}

	function ChargerMake($id)
	{
		$Donnees = $this->bdd->query('SELECT Texte FROM Make WHERE ID = '.$id)->fetch();
		echo "<article style=\"padding-top: 20px;\">".$Donnees['Texte']."</article>";
	}

	function EndPage()
	{
		?>
		</body>
		</html>
		<?php
	}

	function Erreur($Code)
	{
		if($Code == 404)
		{
			header("HTTP/1.0 404 Not Found");
		}
	}
}
?>
