function DivisionR(a, b)
{
	return[Math.floor(a/b), (a/b-Math.floor(a/b))*b];
}
function Exposant(a, b, n)
{
	var Module = Math.sqrt(a*a + b*b);
	var Argument;
	if(a != 0)
	{
		Argument = Math.atan(b/a);
		if(a < 0)
		{
			Argument += Math.PI;
		}
	}
	else
	{
		if(b > 0)
		{
			Argument = Math.PI/2;
		}
		else
		{
			Argument = -Math.PI/2;
		}	
	}
	Module = Math.pow(Module, n);
	Argument *= n;
	a = Module*Math.cos(Argument);
	b = Module*Math.sin(Argument);
	return [a, b];
}
function Fractale(Precision, x, y, Racine, Puissance, Accurate)
{
	var n = 0;
	var Succes = true;
	var Attirance = false;
	for(var i = 0; i < Racine.length; i++)
	{
		if(Math.sqrt(Math.pow(x - Racine[i][0], 2) + Math.pow(y - Racine[i][1], 2)) < Accurate)
		{
			Succes = false;
			Attirance = (function(i){return i})(i);
		}
	}
	while(n < Precision && Succes)
	{
		First = Exposant(x, y, Puissance);
		First[0] -= 1;
		Second = Exposant(x, y, Puissance - 1);
		Second[0] *= Puissance;
		Second[1] *= Puissance;
		var Div = Math.pow(Second[0], 2) + Math.pow(Second[1], 2);
		x =  x - (First[0]*Second[0] + First[1]*Second[1])/Div;
		y =  y - (First[1]*Second[0] - First[0]*Second[1])/Div;
		for(var i = 0; i < Racine.length; i++)
		{
			if(Math.sqrt(Math.pow(x - Racine[i][0], 2) + Math.pow(y - Racine[i][1], 2)) < Accurate)
			{
				Succes = false;
				Attirance = (function(i){return i})(i);
			}
		}
		n++;
	}
	return [n, Attirance];
}
onmessage = function(event)
{
	var Racine = [];
	for(var i = 0; i < event.data[6]; i++)
	{
		Racine.push(function(){return [Math.cos(2*i*Math.PI/event.data[6]), Math.sin(2*i*Math.PI/event.data[6])]}())
	}
	for(var i = 0; i < event.data[0][0]*event.data[0][1]; i++)
	{
		postMessage([DivisionR(i, event.data[0][0])[0], Fractale(event.data[1], DivisionR(i, event.data[0][0])[1]/(event.data[0][0]/(event.data[3] - event.data[2])) + event.data[2], DivisionR(i, event.data[0][0])[0]/(event.data[0][1]/(event.data[5] - event.data[4])) + event.data[4], Racine, event.data[6], event.data[7])]);
	}
	postMessage("Done");
	close();
}