function Com(i, j, Compte, A, Arr)
{
	var Win = A;
	if(Arr[i][j] > 0)
	{
		if(Compte <= 0)
		{
			Compte = 1;
		}
		else
		{
			Compte++;
		}
	}
	else if(Arr[i][j] < 0)
	{
		if(Compte >= 0)
		{
			Compte = -1;
		}
		else
		{
			Compte--;
		}
	}
	else
	{
		Compte = 0;
	}
	if(!Win[0] && Compte < -3)
	{
		Win = [true, -1];
	}
	else if(!Win[0] && Compte > 3)
	{
		Win = [true, 1];
	}
	return [Win, Compte];
}
function Look(Arr)
{
	var Win = [false, 0];
	var Compte;
	for(var i = 0; i < 7; i++)
	{
		Compte = 0;
		for(var j = 0; j < 6; j++)
		{
			Pro = Com(i, j, Compte, Win, Arr);
			Win = Pro[0];
			Compte = Pro[1];
		}
	}
	for(var j = 0; j < 6; j++)
	{
		Compte = 0;
		for(var i = 0; i < 7; i++)
		{
			Pro = Com(i, j, Compte, Win, Arr);
			Win = Pro[0];
			Compte = Pro[1];
		}
	}
	var i;
	var j;
	for(var k = 2; k > 0; k--)
	{
		Compte = 0;
		j = k;
		i = 0;
		while(i < 7 && j < 6)
		{
			Pro = Com(i, j, Compte, Win, Arr);
			Win = Pro[0];
			Compte = Pro[1];
			i++;
			j++;
		}
		Compte = 0;
		j = k;
		i = 6;
		while(i >= 0 && j < 6)
		{
			Pro = Com(i, j, Compte, Win, Arr);
			Win = Pro[0];
			Compte = Pro[1];
			i--;
			j++;
		}
	}
	for(var k = 0; k < 4; k++)
	{
		Compte = 0;
		i = k;
		j = 0;
		while(i < 7 && j < 6)
		{
			Pro = Com(i, j, Compte, Win, Arr);
			Win = Pro[0];
			Compte = Pro[1];
			i++;
			j++;
		}
		Compte = 0;
		i = 6 - k;
		j = 0;
		while(i >= 0 && j < 6)
		{
			Pro = Com(i, j, Compte, Win, Arr);
			Win = Pro[0];
			Compte = Pro[1];
			i--;
			j++;
		}
	}
	return Win;
}
function Put(Table, Data, Value)
{
	var i = 0;
	while(Table[Data][i] == 0)
	{
		i++;
	}
	if(i > 0)
	{
		Table[Data][--i] = Value;
	}
	return Table;
}
function Poss(Table, Data)
{
	var i = 0;
	while(i < 7 && Table[Data][i] == 0)
	{
		i++;
	}
	if(i > 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
function Copie(Parametre)
{
	var Copie = [];
	for(var i = 0; i < 7; i++)
	{
		var Table = [];
		for(var j = 0; j < 6; j++)
		{
			Table.push(Parametre[i][j]);
		}
		Copie.push(Table);
	}
	return Copie;
}
function Recurrence(Arr, Niveau, Maximal)
{
	var Situation = Look(Arr);
	if(!Situation[0])
	{
		if(Niveau < Maximal)
		{
			var Chaise;
			var Poids = 0;
			var Pro = 1 - (Niveau%2)*2;
			for(var i = 0; i < 7; i++)
			{
				Chaise = Copie(Arr);
				if(Poss(Chaise, i))
				{
					Chaise = Put(Chaise, i, Pro);
					Poids += Recurrence(Chaise, Niveau + 1, Maximal);
				}
			}
			return Poids*1/(Niveau*6);
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return Situation[1]/(Niveau*6);
	}
}
onmessage = function(event)
{
	var Tableau = event.data[0];
	var Weight = [];
	var Table;
	for(var i = 0; i < 7; i++)
	{
		Table = Copie(Tableau);
		if(Poss(Table, i))
		{
			Table = Put(Table, i, 1);
			Weight.push(Recurrence(Table, 1, event.data[1]));
		}
		else
		{
			Weight.push(false);
		}
	}
	var i = 0;
	while(Weight[i] === false)
	{
		i++;
	}
	var Max = Weight[i];
	var Min = Max;
	for(var j = i; j < 7; j++)
	{
		if(Weight[j] !== false && Max < Weight[j])
		{
			Max = Weight[j];
		}
		if(Weight[j] !== false && Min > Weight[j])
		{
			Min = Weight[j];
		}
	}
	if(Max < 1 && Min == -1)
	{
		Max = Min;
	}
	var Rand = [];
	var D = 0;
	for(var i = 0; i < Weight.length; i++)
	{
		if(Weight[i] === Max)
		{
			Rand.push(i);
			D++;
		}
	}
	postMessage([Rand[~~(Math.random()*D)], Weight]);
}