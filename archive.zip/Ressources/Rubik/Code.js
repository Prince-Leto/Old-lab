window.location = '/Nouveau/Rubik.html';
