function DivisionR(a, b)
{
	return[Math.floor(a/b), (a/b-Math.floor(a/b))*b];
}
function Fractale(Precision, x, y, c, d)
{
	var a = x;
	var b = y;
	var n = 0;
	while(n < Precision && a*a + b*b < Math.max(4, x*x + y*y))
	{
		var Pro = a;
		a = a*a - b*b;
		b = 2*Pro*b;
		if(c === "x")
		{
			a += x;
		}
		else
		{
			a += c;
		}
		if(d === "y")
		{
			b += y;
		}
		else
		{
			b += d;
		}
		n++;
	}
	return n;
}
onmessage = function(event)
{
	for(var i = 0; i < event.data[0][0]*event.data[0][1]; i++)
	{
		postMessage([DivisionR(i, event.data[0][0])[0], Fractale(event.data[1], DivisionR(i, event.data[0][0])[1]/(event.data[0][0]/(event.data[3] - event.data[2])) + event.data[2], DivisionR(i, event.data[0][0])[0]/(event.data[0][1]/(event.data[5] - event.data[4])) + event.data[4], event.data[6], event.data[7])]);
	}
	postMessage("Done");
	close();
}