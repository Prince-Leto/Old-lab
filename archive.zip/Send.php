<?php
if(isset($_POST['Ref']) and isset($_POST['Message']) and !empty($_POST['Ref']) and !empty($_POST['Message']) and is_numeric($_POST['Ref']))
{
	require_once("Connexion.php");
	$_POST['Message'] = str_replace("'", "\'", $_POST['Message']);
	$_POST['Message'] = str_replace("\"", "\\\"", $_POST['Message']);
	echo $bdd->exec('INSERT INTO Commentaires(Reference, Texte, IP, Temps) VALUES("'.$_POST['Ref'].'", "'.$_POST['Message'].'", "'.$_SERVER['REMOTE_ADDR'].'", "'.time().'")');
	
	$message_html = "<html><head></head><body>Nouveau commentaire sur l'article ".$_POST['Ref'].".<br />Contenu : ".$_POST['Message']."</body></html>";
	$boundary = "-----=".md5(rand());		 
	$sujet = "Nouveau commentaire de ".$_SERVER['REMOTE_ADDR'];
	$header = "From: \"Lelaboratoiredeleto\"<admin@lelaboratoiredeleto.tk>\r\n";
	$header .= "Reply-to: \"Lelaboratoiredeleto\"<admin@lelaboratoiredeleto.tk>\r\n";
	$header .= "MIME-Version: 1.0\r\n";
	$header .= "Content-Type: multipart/alternative;\r\n boundary=\"$boundary\"\r\n";
	$message = "\r\n"."--".$boundary."\r\n";
	$message .= "Content-Type: text/html; charset=\"UTF-8\"\r\n";
	$message .= "Content-Transfer-Encoding: 8bit\r\n";
	$message .= "\r\n".$message_html."\r\n";
	$message .= "\r\n"."--".$boundary."--\r\n";
	$Output = mail("gchauvet.home@gmail.com", $sujet, $message, $header);
}
?>