-- MySQL dump 10.13  Distrib 5.5.35, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: Data
-- ------------------------------------------------------
-- Server version	5.5.35-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Articles`
--

DROP TABLE IF EXISTS `Articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Articles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Titre` varchar(255) NOT NULL,
  `Ressources` varchar(255) NOT NULL,
  `Contenu` text NOT NULL,
  `Description` text NOT NULL,
  `Plus` text NOT NULL,
  `Keywords` text NOT NULL,
  `Date` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Articles`
--

LOCK TABLES `Articles` WRITE;
/*!40000 ALTER TABLE `Articles` DISABLE KEYS */;
INSERT INTO `Articles` VALUES (1,'Le Jeu de la Vie','Jeudelavie','Le Jeu de la Vie est un automate cellulaire inventé par Conway en 1970. On définit des règles régissant l\'évolution des cellules sur un plan et on observe le résultat.<br />À chaque instant, on regarde toutes les cellules et ses huit voisines :<br /><span class=\"List\">Une cellule en vie le reste si elle a deux ou trois voisines, sinon elle meurt.</span><br /><span class=\"List\">Une cellule morte naît si elle a précisément trois voisines.</span><br />Les mathématiciens se sont penchés sur ce jeu et en ont extirpé et nommé quelques structures. Parmi les plus fadas certains l\'ont même utilisé pour créer des portes logiques.<br />\r\nEux raisonnaient dans un plan infini, mais pour faciliter la conception on peut travailler sur un Tore <img src=\"Ressources/Jeudelavie/Torus.png\" alt=\"Tore\" style=\"vertical-align: middle;\"/> : chaque côté communique avec son opposé. C\'est ce que j\'ai fait ici et je vous invite à essayer mon implémentation qui n\'a certes rien de novatrice, mais qui est assez pratique à utiliser grâce aux nouveaux standards HTML5.','Le Jeu de la Vie de Conway en HTML5.','','jeu de la vie, animé, tore, automate-cellulaire, cellule',1319645280),(2,'Fractales et ensembles de Julia','Fractale','Les ensembles fractales sont des surfaces créées selon des lois mathématiques et ayant quelques particularités : <br /><span class=\"List\">Une dimension non-entière.</span><br /><span class=\"List\">Des similarités à petite échelle.</span><br />La plus connue est la <a href=\"http://fr.wikipedia.org/wiki/Ensemble_de_Mandelbrot\">Fractale de Mandelbrot</a> qui est dérivée des ensembles de Julia. Je ne détaillerai pas trop ce que d\'autres expliquent mieux que moi. Si vous voulez en savoir plus sur la Fractale de Mandelbrot, je vous donne rendez-vous sur <a href=\"http://www.siteduzero.com/tutoriel-3-344309-dessiner-la-fractale-de-mandelbrot.html\">le site du zéro</a>.<br />La particularité de mon implémentation est l\'exploitation des Workers en Javascript : c\'est-à-dire que la génération se fera plus rapidement grâce aux capacités multi-coeur de votre ordinateur s\'il en a.','La fractale de Mandelbrot et ensembles de Julia générés en HTML5 avec les Workers Javascript.','','fractale, Mandelbrot, Julia, mathématique, image',1328449751),(3,'Le Jeu de la Vie - Extensible','JeudelavieExtensible','Voilà le même Jeu de la Vie, mais avec une implémentation un peu différente, ici, on va travailler en espace infini. C\'est-à-dire que si les cellules ont besoin de place, elles vont agrandir le cadre. C\'était un peu plus dur à faire et je me suis pas mal gratté la tête avant d\'y arriver. Amusez-vous bien.','','','jeu de la vie, extensible, infini, animé, plan infini, surface infinie',1320340080),(4,'Démineur','Demineur','Voici un petit jeu de démineur, facile à faire, mais néanmoins intéressant. Je vous ne ferai pas l\'affront de vous expliquer son principe.','','','démineur',1329906569),(5,'Feu de Forêt','Feu','Voici un autre automate cellulaire. Le principe de celui-ci, c\'est de disposer des arbres au hasard, et de mettre le feu à la rangée du bas. Il suffit ensuite de le regarder se propager aux arbres voisins.<br />On observe un pourcentage de densité des arbres où en dessous duquel la probabilité que le feu traverse la forêt est faible. Cette valeur est appelée seuil de percolation et il est de 55 %. Je vous invite à essayer mon algorithme pour en juger par vous-même.','','','feu de forêt, automate-cellulaire, percolation, seuil, animé',1337529124),(6,'Déformations bijectives d\'image','Deformation','Quel titre barbare. Tout ça pour dire que l\'on va s\'amuser à déplacer des pixels sur une image sans en perdre. En répétant un grand nombre de fois la même transformation la théorie nous dis que l\'on va retomber sur l\'image de départ. Jugez par vous-même en cliquant sur mon petit lien.<br />Je vous ai mis trois transformations différentes :<br /><span class=\"List\">Celle du boulanger où l\'on étire l\'image puis on la replie par-dessous.</span><br /><span class=\"List\">Celle du photomaton : l\'image est dupliquée en miniatures.</span><br /><span class=\"List\">Et une autre que j\'ai appelée transformation en diagonale.</span><br />J\'ai également un petit quelque chose à dire sur l\'image utilisée par défaut : il s\'agit de <a href=\"http://fr.wikipedia.org/wiki/Lenna\">Lena Sjööblom</a>, considérée comme la première femme d\'internet. L\'histoire se passe en 1973 où des mecs pour tester leur algorithme de traitement d\'image prirent le premier magazine qu\'ils avaient sous la main : le dernier numéro de Playboy. Ils en découpèrent un bout et depuis lors, cette image est mondialement connue et utilisée par tous.','','','bijection, déformation, image, Lena Sjööblom, transformation, boulanger, photomaton',1337968033),(7,'Figures autosimilaires','Autosimilaire','Les figures autosimilaires sont d\'autres ensembles fractales : d\'une part parce que leur dimension topologique n\'est pas un nombre entier et d\'autre part parce que chaque morceau d\'elle-même est encore la figure originale. Pour ne pas faire trois articles un peu vides, j\'ai fait du trois en un : <br /><span class=\"List\">D\'abord, vous avez Le Flocon de Von Koch, il est créé en partant d\'un triangle et en remplaçant le tiers du milieu de chaque segment par deux autres de la même taille en forme de pointe.</span><br /><span class=\"List\">Vous avez également Le Triangle de Sierpinski où l\'on enlève à chaque triangle le plus gros triangle équilatéral inscrit.</span><br /><span class=\"List\">Et, sans doute la plus intéressante : La fractale du Dragon. Si vous plier dans le même sens une bande de papier un certain nombre de fois puis que vous la dépliez en mettant tous les angles à quatre-vingt-dix degrés vous aurez une figure assez sympa. La douzième itération correspond à celle que l\'on appelle La Fractale du Dragon.</span><br />\r\nEncore une fois pour comprendre mon charabia, je vous donne un lien apportant la lumière sur mes dires : direction <a href=\"http://sciences.siteduzero.com/tutoriel-3-546652-les-fractales.html\">le site du zéro</a>.','','','figure, autosimilaire, flocon, Von Koch, triangle, Sierpinski, fractale, dragon',1338561203),(8,'La Fourmi de Langton','Fourmi','Chouette, un autre automate cellulaire ! Pour simplifier, on considère une seule fourmi et deux couleurs. Le sol est découpé en cases initialement remplies de la première couleur. La fourmi est placée sur le sol et elle tourne à gauche ou à droite en fonction de la couleur du sol tout en changeant la couleur de la case une fois qu\'elle est passée. On obtient un automate cellulaire plutôt sympa. Après on peut passer au niveau supérieur en ajoutant des couleurs.\r\nEt la propriété encore jamais démontrée, c\'est que la fourmi finit toujours par se construire une autoroute pour diverger vers l\'infini - même si mon implémentation actuelle fait évoluer la fourmi sur un Tore.<br />\r\nMon explication n\'étant pas très claire, je vous mets un lien expliquant le principe : <a href=\"http://sciencetonnante.wordpress.com/2011/03/21/la-fourmi-de-langton\">La fourmi de Langton | Science étonnante</a>.','','','fourmi, Langton, animé, automate-cellulaire, couleur, autoroute, diverge',1338997416),(9,'La Fractale de Newton','Newton','Voici un nouveau générateur de Fractale, celui de Newton. Un jour peut être, je déciderai de détailler mes articles et d\'en expliquer le principe. Mais pour l\'instant, ce qui me botte le plus c\'est de dessiner en Javascript. Donc pour comprendre ce qu\'est la Fractale de Newton, je vous invite à consulter ce qu\'en dit <a href=\"http://fr.wikipedia.org/wiki/Fractale_de_Newton\">Wikipédia</a>.<br />J\'ai essayé de faire les choses bien - comme toujours - et je vous ai mis tout plein de paramètres. En fait, j\'ai même repris la plus grosse partie de mon code sur la Fractale de Mandelbrot : la génération est aussi multi-coeur.','','','fractale, Newton',1339228148),(10,'Tetris','Tetris','Peut-être que le Tetris a encore du succès ? En tout cas, c\'était sympa à programmer, je ne m\'en pensais pas capable. Vous avez en petit bonus le thème original de Tetris tiré de la version Gameboy.','','','tetris, musique',1334341878),(11,'Le Jeu de la Vie - 3D','Jeudelavie3D','Enfin le jeu de la vie dans sa version en trois dimensions ! Les règles sont les mêmes que la version en deux dimensions, sauf qu\'ici, le nombre de cellules voisines est porté à vingt-six.<br />C\'est ma création la plus complexe pour l\'instant, il a fallu que je fasse de la 3D avec des fonctions de dessins 2D - la 3D n\'est pas encore terrible en HTML5.\r\n','','','jeu de la vie, 3D, animé, automate-cellulaire, cellule, cube',1347913275),(12,'Puissance 4','Puissance4','Voici venue l\'ère des robots - ces derniers deviennent plus malins que l\'homme et prennent petit à petit l’ascendant. Prouvez à l\'humanité que vous êtes encore plus fort qu\'eux en battant cette intelligence artificielle au puissance 4.<br />C\'est l\'heure du duel !','','','puissance 4, intelligence artificielle, IA',1349377846),(13,'Générateur de Labyrinthe','Labyrinthe','Et hop, voici que quoi passer de longues heures à résoudre des labyrinthes toujours plus complexes. Ou pas... Personnellement, moi ça m\'ennuie vite. Par contre les générer, ça, j\'ai adoré.<br />Amusez-vous bien.','','','générateur, labyrinthe, résolution, image, animé',1353193780),(14,'Labyrinthes Circulaires','LabyrintheCirculaire','Voici maintenant des labyrinthes circulaires. J\'ai eu beaucoup de mal à modéliser le problème, mais j\'ai fini par trouver quelque chose de satisfaisant. Venez essayer d\'en résoudre !','Générateur inédit de labyrinthe circulaire en ligne. Il est paramétrable à volonté et permet de d\'enregistrer les images pour une impression.','','labyrinthe, circulaire, générateur, résolution, image',1355505313),(15,'Snake','Snake','Salut tout le monde !<br />\r\nUn petit jeu de snake pour bien commencer la nouvelle année.','','','Snake, jeu',1357385228),(17,'Waveform 3D','Waveform','Enfin un nouvel article ! Voici la représentation 3D de l\'amplitude d\'une musique.<br />\nMerci à <a href=\"http://soundcloud.com/iamcook/\">I am cook</a> et à <a href=\"https://soundcloud.com/luke-paris\">Luke Paris</a> pour les musiques, n\'hésitez pas à visiter leur profil SoundCloud.<br />\n<br />\n<span style=\"color: orange;\">Attention, cette démo ne marche pas sous Firefox, à cause du format MP3, qui est propriétaire, et donc non accepté par Firefox.</span>','','Je vous aurai bien permis d\'importer vous même vos propres musiques, mais la méthode que j\'utilise ne me permet pas de générer les données nécéssaires sur un hébergement mutualisé. Il me faudrait un serveur dédié. De plus, le temps d\'upload pour un MP3 de taille moyenne est un peu long.<br />\n<br />Allez voir la page « <a href=\"/Make-17\">Making Of</a> » si vous voulez plus de détails sur la méthode de génération. D\'ailleurs, si quelqu\'un à une autre méthode à me proposer, qu\'il n\'hésite pas à m\'en parler.','',1368885395);
/*!40000 ALTER TABLE `Articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Commentaires`
--

DROP TABLE IF EXISTS `Commentaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Commentaires` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Reference` int(11) NOT NULL,
  `Texte` text NOT NULL,
  `IP` varchar(15) NOT NULL,
  `Temps` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Commentaires`
--

LOCK TABLES `Commentaires` WRITE;
/*!40000 ALTER TABLE `Commentaires` DISABLE KEYS */;
INSERT INTO `Commentaires` VALUES (1,3,'La configuration 0 0 1 / 1 0 1 / 0 1 1 sur un carré 3x3 et avec Noir = 1 et Blanc = 0 donne un motif qui s\'en va à l\'infini. Une amélioration possible serait d\'ajouter l\'option \"mettre en pause\". Bravo à toi pour ce petit jeu.','82.228.76.35',1339320475),(2,1,'Juste une chose à dire : bravo ! C\'est vraiment bien fait.','88.186.116.52',1339855528),(3,8,'Pour obtenir une figure symétrique (une sorte de carré dans un carré), il y a la combinaison [[0, \"black\"], [1, \"white\"], [1, \"blue\"], [1, \"green\"]] avec 4 fourmis placées en forme de carré.','90.45.175.72',1341221306),(4,8,'Effectivement. Bien trouvé. Tu remarqueras que deux fourmis côte à côte suffisent pour faire un carré simple.<br />Sinon pour des formes complexes très sympa, je propose d\'aller voir la vidéo dans le lien que j\'ai fourni en description.<br />Merci pour le commentaire - que me suis d\'ailleurs permis d\'éditer pour plus de clarté.','89.87.219.96',1341225912),(6,3,'Merci pour ta remarque. L\'option a été ajoutée.<br />Le motif que tu me décrit est connu, il s\'agit d\'un planeur. Il en existe une multitude. Certains ont même trouvé des générateurs de vaisseaux ou de planeurs. Je te conseille d\'aller voir sur Wikipédia dont les articles sur le jeu de la vie sont assez complets pour plus de détails et de structures intéressantes.','89.87.219.96',1341227225),(7,8,'Deux fourmis côte à côte mais en colonne ! J\'ai commencé par les mettre en ligne et elles m\'ont donné une petite figure sur laquelle elles restent et qu\'elles font passer du noir au blanc.','90.45.45.211',1341437904),(8,8,'Ah bon ? Chez moi en ligne ça marche aussi.<br />Mais je me rends compte d\'une erreur dans mon code : impossible de supprimer une fourmi déjà placée, si tu clique sur une cellule où une fourmi était présente tu en superpose une deuxième. Peut être est-ce la source de notre désaccord ? En tout cas il faut que je corrige ce problème.','89.87.219.96',1341671861),(9,8,'Je confirme que deux fourmis côte à côte donne une structure répétitive bornée.<br /><a href=\"http://i45.servimg.com/u/f45/13/45/85/82/fourmi10.png\">La disposition initiale</a><br /><a href=\"http://i45.servimg.com/u/f45/13/45/85/82/fourmi11.png\">La structure</a> (où tout est repassé en noir, hasard du moment où j\'ai pris le screen).','90.45.45.211',1341751599),(10,8,'D\'accord. Et je vois ce qui est la cause de notre malentendu : moi j\'utilisais les couleurs que tu fournissais dans ton premier commentaire, tandis que toi, tu utilises celles qui sont entrées par défaut. D\'ailleurs, j\'ignorais qu\'avec ces couleurs et des fourmis en colonne on obtenait un carré.<br />Mais pourquoi il y a une différence entre des fourmis en ligne et d\'autres en colonne ?<br />C\'est parce que dans mon implémentation je les place arbitrairement orientées vers le haut, et je ne laisse jamais la possibilité de modifier cette propriété.','86.220.156.58',1341781612),(12,12,'Balèze quand même le robot. Je l\'ai mis à 7 coups prévu et j\'ai pas réussi à gagner, mais la bonne chose c\'est qu\'il n\'a pas gagné non plus ! - Nico','88.186.116.52',1352567103),(13,11,'Cool !','85.171.136.14',1352891304),(14,13,'Sympa, il m\'a fallu plusieurs essais avant de trouver la sortie !','78.127.190.175',1355785998),(15,14,'On ne peut pas bouger à celui là par contre ?','78.127.190.175',1355786047),(16,14,'Non, désolé. Et pour une raison simple, qui rend la chose difficile.<br />\r\nJe te donne un <a href=\"http://img11.hostingpics.net/pics/171991Exemple.jpg\">exemple</a>. Sur l\'image, quand les deux choix en rouge se présentent à l\'utilisateur je ne vois pas comment deviner sur quelle case il souhaite aller, en n\'exploitant que les touches fléchées. Il faudrait faire quelque chose de plus complexe - à faire et à utiliser.','89.87.219.96',1355856907),(21,5,'J\'ai l\'impression qu\'il y a une erreur sur le pourcentage réel, il est identique au pourcentage d\'arbres.','144.204.16.1',1365505729),(20,5,'Ahhhh j\'ai cramé la forêt des Landes !<br />SUPER COCO !','109.214.199.91',1363638563),(22,15,'Et si tu nous refilais les scripts, au lieu de faire ton malin, ça serait pas plus sympa ?','90.84.144.155',1365537712),(23,5,'Mouai... C\'est normal. J\'explique mal, c\'est de ma faute. Je devrais enlever ce truc.<br />En fait, le pourcentage d\'arbre, c\'est plutôt une probabilité d\'avoir des arbres, c\'est comme ça que je les génères. Mais j\'affiche le pourcentage réel en comptant combien j\'ai réellement d\'arbres. En réalité c\'était surtout pour pouvoir ajouter la balise <code>&lt;meter&gt;</code>.','89.87.219.96',1365540250),(24,15,'Je sais, je sais. J\'essaye de faire des pages où j\'explique ce que je fait. Mais ça prend du temps, et je ne suis pas sûr d\'être très bon pédagogue.<br />Quoi qu\'il en soit j\'ai commencé à expliquer le principe du Jeu de la Vie en 3D à cette <a href=\"Make.php\">adresse</a>. Ce n\'est qu\'un premier jet. Ne m\'en voulez pas trop si c\'est pas terrible.','89.87.219.96',1365541308),(25,15,'Mais elle est parfaite ton explication.','90.84.144.190',1365692506),(78,17,'Merci à toi de nous faire de la pub ^^ Sinon ça rend vraiment bien, bravo ! - Luke','90.11.198.228',1368958026),(26,15,'Yes, merci, c\'est motivant pour continuer. Par contre je manque actuellement de temps. J\'espère m\'y mettre d\'ici Juin-Juillet.','89.87.219.96',1365709729);
/*!40000 ALTER TABLE `Commentaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Make`
--

DROP TABLE IF EXISTS `Make`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Make` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Reference` int(11) NOT NULL,
  `Texte` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Make`
--

LOCK TABLES `Make` WRITE;
/*!40000 ALTER TABLE `Make` DISABLE KEYS */;
INSERT INTO `Make` VALUES (2,17,'Cette page est en cours d\'écriture...<br />\n<br />\nPour ceux qui seraient curieux, la « waveform » est générée en suivant la méthode décrite ici : <a href=\"http://andrewfreiday.com/2010/04/29/generating-mp3-waveforms-with-php/\">Generating MP3 waveforms with PHP | andrewfreiday.com</a>.');
/*!40000 ALTER TABLE `Make` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-10 15:40:17
