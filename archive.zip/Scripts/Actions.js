window.onload = function()
{
	document.querySelector("#Prev").addEventListener("click", function()
	{
		document.querySelector("#RContent").innerHTML = document.querySelector("#Content").value;
		document.querySelector("#RContent").value = document.querySelector("#Content").value;
		document.querySelector("input[type=submit]").disabled = false;
		MathJax.Hub.Queue(["Typeset",MathJax.Hub]);
	}, false);
	document.querySelector("form").addEventListener("submit", function()
	{
		document.querySelector("#RMessage").value = document.querySelector("#RContent").innerHTML;
		var Chaine = "";
		for(var i = 0; i < document.querySelectorAll("style").length; i++)
		{
			Chaine += document.querySelectorAll("style")[i].innerHTML;
		}
		document.querySelector("#RStyle").value = Chaine;
	}, false);
	document.querySelector("textarea").addEventListener("keydown", function()
	{
		document.querySelector("input[type=submit]").disabled = true;
	}, false);
}